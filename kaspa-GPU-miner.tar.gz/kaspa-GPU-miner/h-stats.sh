#!/usr/bin/env bash

#######################
# MAIN script body
#######################

. /hive/custom/nanominer/h-manifest.conf


